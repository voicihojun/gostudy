package main

func asmFunc()

func main() {
	asmFunc()
}
